(() => {
  if (window.__instaUnfollowersLoadedV22) return;
  window.__instaUnfollowersLoadedV22 = true;

  // Remove old UI if an older version was injected in the same tab
  const oldRoot = document.getElementById("iu-root");
  if (oldRoot) oldRoot.remove();

  const IG_APP_ID = "936619743392459";
  const FOLLOWERS_QUERY_HASH = "c76146de99bb02f6415203be841dd25a";
  const FOLLOWING_QUERY_HASH = "d04b0a864b4b54837c0d870b0e77e076";
  const WHITELIST_KEY = "iu_whitelist_v2";
  const CACHE_KEY = "iu_scan_cache_v2";

  const savedCache = (() => {
    try {
      return JSON.parse(localStorage.getItem(CACHE_KEY) || "null");
    } catch (_) {
      return null;
    }
  })();

  let state = {
    scanning: false,
    unfollowing: false,
    stopRequested: false,
    followers: savedCache?.followers || [],
    following: savedCache?.following || [],
    nonFollowers: [],
    mutuals: [],
    fans: [],
    whitelist: new Set(JSON.parse(localStorage.getItem(WHITELIST_KEY) || "[]")),
    selectedIds: new Set(),
    activeTab: "nonFollowers",
    searchQuery: "",
    hideVerified: false,
    hidePrivate: false
  };

  const localBlobCache = new Map();

  function saveWhitelist() {
    localStorage.setItem(WHITELIST_KEY, JSON.stringify([...state.whitelist]));
  }

  function saveScanCache() {
    try {
      localStorage.setItem(
        CACHE_KEY,
        JSON.stringify({
          followers: state.followers,
          following: state.following,
          updatedAt: Date.now()
        })
      );
    } catch (_) {}
  }

  function getCookie(name) {
    const match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
    return match ? decodeURIComponent(match[2]) : null;
  }

  function getCsrfToken() {
    const fromCookie = getCookie("csrftoken");
    if (fromCookie) return fromCookie;
    const html = document.documentElement.innerHTML;
    const m = html.match(/"csrf_token":"([^"]+)"/);
    return m ? m[1] : "";
  }

  function getUserId() {
    const fromCookie = getCookie("ds_user_id");
    if (fromCookie) return fromCookie;
    const html = document.documentElement.innerHTML;
    const patterns = [
      /"viewerId":"(\d+)"/,
      /"actorID":"(\d+)"/,
      /"ds_user_id":"(\d+)"/,
      /"user_id":"(\d+)"/
    ];
    for (const pat of patterns) {
      const m = html.match(pat);
      if (m && m[1] && m[1] !== "0") return m[1];
    }
    return null;
  }

  const sleep = (ms) => new Promise((res) => setTimeout(res, ms));
  const jitter = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

  function igHeaders() {
    return {
      "X-IG-App-ID": IG_APP_ID,
      "X-CSRFToken": getCsrfToken(),
      "X-Requested-With": "XMLHttpRequest",
      "Accept": "*/*"
    };
  }

  // Resolve profile picture bypassing Instagram's Cross-Origin-Embedder-Policy (COEP)
  async function loadAvatarSafe(imgEl, url) {
    if (!url) return;
    if (localBlobCache.has(url)) {
      imgEl.src = localBlobCache.get(url);
      imgEl.style.opacity = "1";
      return;
    }

    // 0. Native Android APK Bridge (when running inside the compiled APK)
    if (typeof window.AndroidBridge !== "undefined" && window.AndroidBridge.fetchAvatarBase64) {
      try {
        const dataUrl = window.AndroidBridge.fetchAvatarBase64(url);
        if (dataUrl && dataUrl.startsWith("data:")) {
          localBlobCache.set(url, dataUrl);
          imgEl.src = dataUrl;
          imgEl.style.opacity = "1";
          return;
        }
      } catch (_) {}
    }

    // 1. Try extension background worker proxy first (immune to page COEP/CORP headers)
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
      try {
        const response = await new Promise((resolve) => {
          chrome.runtime.sendMessage({ action: "FETCH_AVATAR", url }, (res) => {
            if (chrome.runtime.lastError) resolve(null);
            else resolve(res);
          });
        });
        if (response && response.ok && response.dataUrl) {
          localBlobCache.set(url, response.dataUrl);
          imgEl.src = response.dataUrl;
          imgEl.style.opacity = "1";
          return;
        }
      } catch (_) {}
    }

    // 2. Fallback: fetch with CORS mode omitted credentials and convert to Blob URL
    try {
      const res = await fetch(url, { mode: "cors", credentials: "omit" });
      if (res.ok) {
        const blob = await res.blob();
        const blobUrl = URL.createObjectURL(blob);
        localBlobCache.set(url, blobUrl);
        imgEl.src = blobUrl;
        imgEl.style.opacity = "1";
        return;
      }
    } catch (_) {}

    // 3. Direct crossorigin="anonymous" fallback
    imgEl.crossOrigin = "anonymous";
    imgEl.src = url;
  }

  async function fetchListV1(userId, type, onProgress) {
    const endpoint = type === "followers" ? "followers" : "following";
    let results = [];
    let maxId = "";
    let page = 0;

    while (true) {
      if (state.stopRequested) throw new Error("Varredura interrompida pelo usuário.");
      const url = `https://www.instagram.com/api/v1/friendships/${userId}/${endpoint}/?count=50${maxId ? `&max_id=${encodeURIComponent(maxId)}` : ""}`;
      const res = await fetch(url, {
        method: "GET",
        headers: igHeaders(),
        credentials: "include"
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status} na API v1`);
      }

      const data = await res.json();
      if (!data || !Array.isArray(data.users)) {
        throw new Error("Formato inesperado na API v1");
      }

      for (const u of data.users) {
        results.push({
          id: String(u.pk || u.pk_id || u.id),
          username: u.username,
          full_name: u.full_name || "",
          profile_pic_url: u.profile_pic_url || u.hd_profile_pic_url_info?.url || "",
          is_verified: Boolean(u.is_verified),
          is_private: Boolean(u.is_private)
        });
      }

      page++;
      onProgress(results.length);

      if (!data.big_list || !data.next_max_id) break;
      maxId = data.next_max_id;

      await sleep(jitter(900, 1700));
      if (page % 5 === 0) {
        onProgress(results.length, "Pausa rápida anti-bloqueio (4s)...");
        await sleep(jitter(3500, 4800));
      }
    }
    return results;
  }

  async function fetchListGraphQL(userId, type, onProgress) {
    const queryHash = type === "followers" ? FOLLOWERS_QUERY_HASH : FOLLOWING_QUERY_HASH;
    const edgeKey = type === "followers" ? "edge_followed_by" : "edge_follow";
    let results = [];
    let hasNext = true;
    let endCursor = null;
    let page = 0;

    while (hasNext) {
      if (state.stopRequested) throw new Error("Varredura interrompida pelo usuário.");
      const variables = {
        id: userId,
        include_reel: false,
        fetch_mutual: false,
        first: 50,
        after: endCursor
      };
      const url = `https://www.instagram.com/graphql/query/?query_hash=${queryHash}&variables=${encodeURIComponent(JSON.stringify(variables))}`;
      const res = await fetch(url, {
        method: "GET",
        headers: igHeaders(),
        credentials: "include"
      });

      if (!res.ok) {
        throw new Error(`HTTP ${res.status} no GraphQL`);
      }

      const json = await res.json();
      const edgeObj = json?.data?.user?.[edgeKey];
      if (!edgeObj) {
        throw new Error("Resposta GraphQL inválida ou limite temporário atingido.");
      }

      for (const item of edgeObj.edges || []) {
        const u = item.node;
        if (!u) continue;
        results.push({
          id: String(u.id),
          username: u.username,
          full_name: u.full_name || "",
          profile_pic_url: u.profile_pic_url || "",
          is_verified: Boolean(u.is_verified),
          is_private: Boolean(u.is_private)
        });
      }

      hasNext = Boolean(edgeObj.page_info?.has_next_page);
      endCursor = edgeObj.page_info?.end_cursor || null;
      page++;
      onProgress(results.length);

      if (hasNext) {
        await sleep(jitter(1000, 1800));
        if (page % 5 === 0) {
          onProgress(results.length, "Pausa rápida anti-bloqueio (4s)...");
          await sleep(jitter(3500, 4800));
        }
      }
    }
    return results;
  }

  async function fetchUsersSmart(userId, type, onProgress) {
    try {
      return await fetchListV1(userId, type, onProgress);
    } catch (errV1) {
      console.warn(`[InstaUnfollowers] API v1 falhou para ${type}, usando fallback GraphQL:`, errV1);
      return await fetchListGraphQL(userId, type, onProgress);
    }
  }

  async function unfollowUserById(targetUserId) {
    const urls = [
      `https://www.instagram.com/api/v1/friendships/destroy/${targetUserId}/`,
      `https://www.instagram.com/web/friendships/${targetUserId}/unfollow/`
    ];
    for (const url of urls) {
      const res = await fetch(url, {
        method: "POST",
        headers: {
          ...igHeaders(),
          "Content-Type": "application/x-www-form-urlencoded"
        },
        credentials: "include"
      });
      if (res.ok) return true;
    }
    throw new Error("Falha ao deixar de seguir HTTP");
  }

  function createUI() {
    if (document.getElementById("iu-root")) return;

    const style = document.createElement("style");
    style.textContent = `
      #iu-fab {
        position: fixed;
        right: 16px;
        bottom: 72px;
        z-index: 999998;
        background: linear-gradient(135deg, #e1306c, #fd1d1d);
        color: #fff;
        border: none;
        border-radius: 999px;
        padding: 11px 16px;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 13px;
        font-weight: 700;
        box-shadow: 0 6px 20px rgba(225, 48, 108, 0.45);
        cursor: pointer;
        display: flex;
        align-items: center;
        gap: 6px;
      }
      #iu-modal {
        position: fixed;
        inset: 0;
        z-index: 999999;
        background: rgba(9, 13, 22, 0.94);
        backdrop-filter: blur(6px);
        display: none;
        flex-direction: column;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        color: #f8fafc;
      }
      #iu-modal.open {
        display: flex;
      }
      .iu-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 14px 16px;
        background: #1e293b;
        border-bottom: 1px solid #334155;
      }
      .iu-title {
        font-size: 16px;
        font-weight: 700;
        color: #f43f5e;
      }
      .iu-close {
        background: #334155;
        color: #f8fafc;
        border: none;
        border-radius: 8px;
        padding: 6px 12px;
        font-size: 13px;
        cursor: pointer;
      }
      .iu-controls {
        padding: 12px 16px;
        background: #0f172a;
        border-bottom: 1px solid #1e293b;
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        align-items: center;
      }
      .iu-btn {
        background: #e1306c;
        color: #fff;
        border: none;
        border-radius: 8px;
        padding: 9px 14px;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
      }
      .iu-btn.secondary {
        background: #334155;
      }
      .iu-btn.danger {
        background: #dc2626;
      }
      .iu-btn:disabled {
        opacity: 0.5;
        cursor: not-allowed;
      }
      .iu-status {
        width: 100%;
        font-size: 12px;
        color: #94a3b8;
        margin-top: 4px;
      }
      .iu-tabs {
        display: flex;
        gap: 4px;
        padding: 8px 16px;
        background: #1e293b;
        overflow-x: auto;
      }
      .iu-tab {
        background: transparent;
        color: #94a3b8;
        border: none;
        padding: 7px 11px;
        border-radius: 6px;
        font-size: 12px;
        font-weight: 600;
        white-space: nowrap;
        cursor: pointer;
      }
      .iu-tab.active {
        background: #e1306c;
        color: #fff;
      }
      .iu-filters {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        padding: 8px 16px;
        background: #0f172a;
        border-bottom: 1px solid #1e293b;
        align-items: center;
      }
      .iu-search {
        flex: 1;
        min-width: 150px;
        background: #1e293b;
        border: 1px solid #334155;
        color: #fff;
        padding: 7px 10px;
        border-radius: 6px;
        font-size: 13px;
      }
      .iu-chip {
        font-size: 12px;
        color: #cbd5e1;
        display: flex;
        align-items: center;
        gap: 4px;
      }
      .iu-list {
        flex: 1;
        overflow-y: auto;
        padding: 12px 16px;
        display: flex;
        flex-direction: column;
        gap: 8px;
      }
      .iu-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        background: #1e293b;
        padding: 10px 12px;
        border-radius: 10px;
        gap: 10px;
      }
      .iu-user {
        display: flex;
        align-items: center;
        gap: 10px;
        min-width: 0;
        flex: 1;
      }
      .iu-avatar-wrap {
        position: relative;
        width: 42px;
        height: 42px;
        border-radius: 50%;
        background: linear-gradient(135deg, #e1306c, #833ab4);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 13px;
        font-weight: 700;
        color: #ffffff;
        flex-shrink: 0;
        overflow: hidden;
        border: 1.5px solid #334155;
      }
      .iu-avatar {
        position: absolute;
        inset: 0;
        width: 100%;
        height: 100%;
        border-radius: 50%;
        object-fit: cover;
        opacity: 0;
        transition: opacity 0.18s ease;
      }
      .iu-meta {
        min-width: 0;
      }
      .iu-username {
        font-size: 13px;
        font-weight: 700;
        color: #f8fafc;
        text-decoration: none;
        display: block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .iu-fullname {
        font-size: 11px;
        color: #94a3b8;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .iu-actions {
        display: flex;
        gap: 6px;
        align-items: center;
      }
      .iu-small-btn {
        background: #334155;
        color: #f8fafc;
        border: none;
        border-radius: 6px;
        padding: 6px 9px;
        font-size: 11px;
        font-weight: 600;
        cursor: pointer;
      }
      .iu-small-btn.unfollow {
        background: #e11d48;
      }
    `;
    document.head.appendChild(style);

    const root = document.createElement("div");
    root.id = "iu-root";
    root.innerHTML = `
      <button id="iu-fab" title="Analisar quem não segue de volta">
        <span>🔍 Não Seguidores</span>
      </button>
      <div id="iu-modal">
        <div class="iu-header">
          <div class="iu-title">InstaUnfollowers Pro • Kiwi</div>
          <button class="iu-close" id="iu-close-btn">Fechar ✕</button>
        </div>
        <div class="iu-controls">
          <button class="iu-btn" id="iu-scan-btn">Iniciar Varredura</button>
          <button class="iu-btn secondary" id="iu-select-all-btn">Selecionar Visíveis</button>
          <button class="iu-btn danger" id="iu-batch-unfollow-btn" disabled>Deixar de Seguir (0)</button>
          <button class="iu-btn secondary" id="iu-export-btn">Copiar Lista</button>
          <div class="iu-status" id="iu-status">Pronto para escanear sua conta logada no Instagram.</div>
        </div>
        <div class="iu-tabs">
          <button class="iu-tab active" data-tab="nonFollowers" id="tab-nonFollowers">Não te seguem (0)</button>
          <button class="iu-tab" data-tab="fans" id="tab-fans">Fãs / Te seguem (0)</button>
          <button class="iu-tab" data-tab="mutuals" id="tab-mutuals">Mútuos (0)</button>
          <button class="iu-tab" data-tab="whitelist" id="tab-whitelist">Protegidos (0)</button>
        </div>
        <div class="iu-filters">
          <input type="text" class="iu-search" id="iu-search-input" placeholder="Filtrar por @usuario ou nome..." />
          <label class="iu-chip"><input type="checkbox" id="iu-hide-verified" /> Ocultar verificados</label>
          <label class="iu-chip"><input type="checkbox" id="iu-hide-private" /> Ocultar privados</label>
        </div>
        <div class="iu-list" id="iu-list"></div>
      </div>
    `;
    document.body.appendChild(root);

    const modal = document.getElementById("iu-modal");
    document.getElementById("iu-fab").addEventListener("click", () => modal.classList.add("open"));
    document.getElementById("iu-close-btn").addEventListener("click", () => modal.classList.remove("open"));
    document.getElementById("iu-scan-btn").addEventListener("click", startScan);
    document.getElementById("iu-select-all-btn").addEventListener("click", toggleSelectAllVisible);
    document.getElementById("iu-batch-unfollow-btn").addEventListener("click", batchUnfollow);
    document.getElementById("iu-export-btn").addEventListener("click", exportCurrentList);

    document.querySelectorAll(".iu-tab").forEach((btn) => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".iu-tab").forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");
        state.activeTab = btn.dataset.tab;
        renderList();
      });
    });

    document.getElementById("iu-search-input").addEventListener("input", (e) => {
      state.searchQuery = e.target.value.trim().toLowerCase();
      renderList();
    });
    document.getElementById("iu-hide-verified").addEventListener("change", (e) => {
      state.hideVerified = e.target.checked;
      renderList();
    });
    document.getElementById("iu-hide-private").addEventListener("change", (e) => {
      state.hidePrivate = e.target.checked;
      renderList();
    });

    if (state.following.length > 0 || state.followers.length > 0) {
      computeDiffs();
      setStatus(
        `Última varredura restaurada! Seguindo: ${state.following.length} | Seguidores: ${state.followers.length} | Não seguem de volta: ${state.nonFollowers.length}`
      );
    } else {
      updateTabCounts();
      renderList();
    }
  }

  function setStatus(text) {
    const el = document.getElementById("iu-status");
    if (el) el.textContent = text;
  }

  function computeDiffs() {
    const followerIds = new Set(state.followers.map((u) => u.id));
    const followingIds = new Set(state.following.map((u) => u.id));

    state.nonFollowers = state.following.filter(
      (u) => !followerIds.has(u.id) && !state.whitelist.has(u.id)
    );
    state.mutuals = state.following.filter((u) => followerIds.has(u.id));
    state.fans = state.followers.filter((u) => !followingIds.has(u.id));
    updateTabCounts();
    renderList();
  }

  function updateTabCounts() {
    const setTab = (id, label, count) => {
      const el = document.getElementById(id);
      if (el) el.textContent = `${label} (${count})`;
    };
    setTab("tab-nonFollowers", "Não te seguem", state.nonFollowers.length);
    setTab("tab-fans", "Fãs / Te seguem", state.fans.length);
    setTab("tab-mutuals", "Mútuos", state.mutuals.length);
    setTab("tab-whitelist", "Protegidos", state.whitelist.size);

    const batchBtn = document.getElementById("iu-batch-unfollow-btn");
    if (batchBtn) {
      batchBtn.textContent = `Deixar de Seguir (${state.selectedIds.size})`;
      batchBtn.disabled = state.selectedIds.size === 0 || state.scanning || state.unfollowing;
    }
  }

  function getVisibleUsers() {
    let source = [];
    if (state.activeTab === "nonFollowers") source = state.nonFollowers;
    else if (state.activeTab === "fans") source = state.fans;
    else if (state.activeTab === "mutuals") source = state.mutuals;
    else if (state.activeTab === "whitelist") {
      source = state.following.filter((u) => state.whitelist.has(u.id));
    }

    return source.filter((u) => {
      if (state.hideVerified && u.is_verified) return false;
      if (state.hidePrivate && u.is_private) return false;
      if (state.searchQuery) {
        const hay = `${u.username} ${u.full_name}`.toLowerCase();
        if (!hay.includes(state.searchQuery)) return false;
      }
      return true;
    });
  }

  function renderList() {
    const container = document.getElementById("iu-list");
    if (!container) return;
    const users = getVisibleUsers();

    if (users.length === 0) {
      container.innerHTML = `<div style="text-align:center;color:#64748b;padding:32px 12px;font-size:13px;">Nenhum perfil para exibir nesta aba.</div>`;
      updateTabCounts();
      return;
    }

    container.innerHTML = "";
    for (const u of users) {
      const row = document.createElement("div");
      row.className = "iu-item";
      const isWhitelisted = state.whitelist.has(u.id);
      const isChecked = state.selectedIds.has(u.id);
      const initials = (u.username || "IG").replace(/[^a-zA-Z0-9]/g, "").slice(0, 2).toUpperCase() || "IG";

      row.innerHTML = `
        <div class="iu-user">
          <input type="checkbox" class="iu-check" data-id="${u.id}" ${isChecked ? "checked" : ""} />
          <div class="iu-avatar-wrap">
            <span>${initials}</span>
            <img class="iu-avatar" alt="" data-pic="${u.profile_pic_url || ""}" />
          </div>
          <div class="iu-meta">
            <a class="iu-username" href="https://www.instagram.com/${u.username}/" target="_blank" rel="noopener">
              @${u.username} ${u.is_verified ? "☑️" : ""} ${u.is_private ? "🔒" : ""}
            </a>
            <div class="iu-fullname">${u.full_name || ""}</div>
          </div>
        </div>
        <div class="iu-actions">
          <button class="iu-small-btn whitelist-btn" data-id="${u.id}">
            ${isWhitelisted ? "Remover ⭐" : "Proteger ⭐"}
          </button>
          <button class="iu-small-btn unfollow" data-id="${u.id}" data-username="${u.username}">
            Unfollow
          </button>
        </div>
      `;
      container.appendChild(row);

      const imgEl = row.querySelector(".iu-avatar");
      if (imgEl && u.profile_pic_url) {
        imgEl.addEventListener("load", () => {
          imgEl.style.opacity = "1";
        });
        imgEl.addEventListener("error", () => {
          imgEl.style.opacity = "0";
        });
        loadAvatarSafe(imgEl, u.profile_pic_url);
      }
    }

    container.querySelectorAll(".iu-check").forEach((chk) => {
      chk.addEventListener("change", (e) => {
        const id = e.target.dataset.id;
        if (e.target.checked) state.selectedIds.add(id);
        else state.selectedIds.delete(id);
        updateTabCounts();
      });
    });

    container.querySelectorAll(".whitelist-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        const id = btn.dataset.id;
        if (state.whitelist.has(id)) state.whitelist.delete(id);
        else {
          state.whitelist.add(id);
          state.selectedIds.delete(id);
        }
        saveWhitelist();
        computeDiffs();
      });
    });

    container.querySelectorAll(".iu-small-btn.unfollow").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        const username = btn.dataset.username;
        btn.disabled = true;
        btn.textContent = "Aguarde...";
        try {
          await unfollowUserById(id);
          state.following = state.following.filter((u) => u.id !== id);
          state.selectedIds.delete(id);
          saveScanCache();
          computeDiffs();
          setStatus(`Você deixou de seguir @${username}.`);
        } catch (err) {
          btn.disabled = false;
          btn.textContent = "Erro";
          setStatus(`Erro ao deixar de seguir @${username}: ${err.message}`);
        }
      });
    });

    updateTabCounts();
  }

  async function startScan() {
    if (state.scanning) {
      state.stopRequested = true;
      return;
    }

    const userId = getUserId();
    if (!userId) {
      setStatus("Erro: Não foi possível detectar sua sessão. Verifique se está logado em instagram.com.");
      return;
    }

    state.scanning = true;
    state.stopRequested = false;
    state.selectedIds.clear();
    const scanBtn = document.getElementById("iu-scan-btn");
    scanBtn.textContent = "Parar Varredura";

    try {
      setStatus("Buscando lista de quem você segue (1/2)...");
      state.following = await fetchUsersSmart(userId, "following", (count, note) => {
        setStatus(`Lendo seguindo: ${count} carregados... ${note || ""}`);
      });

      setStatus("Buscando lista de seguidores (2/2)...");
      state.followers = await fetchUsersSmart(userId, "followers", (count, note) => {
        setStatus(`Lendo seguidores: ${count} carregados... ${note || ""}`);
      });

      saveScanCache();
      computeDiffs();
      setStatus(
        `Concluído! Seguindo: ${state.following.length} | Seguidores: ${state.followers.length} | Não seguem de volta: ${state.nonFollowers.length}`
      );
    } catch (err) {
      setStatus(`Aviso: ${err.message}`);
    } finally {
      state.scanning = false;
      scanBtn.textContent = "Iniciar Varredura";
      updateTabCounts();
    }
  }

  function toggleSelectAllVisible() {
    const visible = getVisibleUsers();
    const allSelected = visible.every((u) => state.selectedIds.has(u.id));
    for (const u of visible) {
      if (allSelected) state.selectedIds.delete(u.id);
      else state.selectedIds.add(u.id);
    }
    renderList();
  }

  async function batchUnfollow() {
    if (state.selectedIds.size === 0 || state.unfollowing) return;
    const ids = [...state.selectedIds];
    state.unfollowing = true;
    updateTabCounts();

    let done = 0;
    for (const id of ids) {
      const user = state.following.find((u) => u.id === id);
      const label = user ? `@${user.username}` : id;
      try {
        setStatus(`Deixando de seguir ${label} (${done + 1}/${ids.length})...`);
        await unfollowUserById(id);
        state.following = state.following.filter((u) => u.id !== id);
        state.selectedIds.delete(id);
        done++;
        saveScanCache();
        computeDiffs();
      } catch (err) {
        setStatus(`Erro em ${label}: ${err.message}. Pausando lote por segurança.`);
        break;
      }

      if (done < ids.length) {
        const waitMs = done % 5 === 0 ? jitter(12000, 18000) : jitter(4000, 7000);
        setStatus(`Proteção anti-bloqueio: aguardando ${Math.round(waitMs / 1000)}s antes do próximo...`);
        await sleep(waitMs);
      }
    }

    state.unfollowing = false;
    updateTabCounts();
    setStatus(`Lote finalizado! ${done} perfis deixados de seguir com segurança.`);
  }

  function exportCurrentList() {
    const users = getVisibleUsers();
    const text = users.map((u) => `@${u.username} (${u.full_name || "Sem nome"})`).join("\n");
    if (typeof window.AndroidBridge !== "undefined" && window.AndroidBridge.copyToClipboard) {
      window.AndroidBridge.copyToClipboard(text);
      setStatus(`${users.length} usuários copiados para a área de transferência!`);
      return;
    }
    navigator.clipboard.writeText(text).then(() => {
      setStatus(`${users.length} usuários copiados para a área de transferência!`);
    });
  }

  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((msg) => {
      if (msg && msg.action === "OPEN_PANEL") {
        createUI();
        const modal = document.getElementById("iu-modal");
        if (modal) modal.classList.add("open");
      }
    });
  }

  createUI();
})();
